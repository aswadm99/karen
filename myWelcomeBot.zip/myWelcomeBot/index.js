const { Client, GatewayIntentBits } = require("discord.js");

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages
    ]
});

const WELCOME_CHANNEL = "ID_CHANNEL_WELCOME";
const GOODBYE_CHANNEL = "ID_CHANNEL_GOODBYE";

client.on("ready", () => {
    console.log(`Bot sudah online sebagai ${client.user.tag}`);
});

client.on("guildMemberAdd", (member) => {
    const channel = member.guild.channels.cache.get(WELCOME_CHANNEL);
    if (!channel) return;
    channel.send(`👋 Selamat datang **${member.user.username}**!`);
});

client.on("guildMemberRemove", (member) => {
    const channel = member.guild.channels.cache.get(GOODBYE_CHANNEL);
    if (!channel) return;
    channel.send(`👋 **${member.user.username}** telah keluar dari server.`);
});

client.login("MTQ0NTQzMDIyOTI3NDMyOTA4OA.GU9LDM.WBlcco8zNjTOGHIttbAM8dAdjJMq9262-IRxTs");
